# Kotlin Android Simple ListView Sort

View full tutorial at Camposha here: http://camposha.info/kotlin-android/listview-sort

# Concepts.

Here are the concepts we implement:

1. [ListView](https://camposha.info/android/listview)


# Full Tutorial

We have a [website](https://camposha.info) and [YouTube channel,ProgrammingWizards TV](http://www.youtube.com/c/programmingwizards). View the full tutorial in them and more tutorials
like this.


|No.|Location|Link|
|---|--------|---------|
|1.|Camposha|[View Full Tutorial](https://camposha.info/kotlin-android/listview-sort)|
|2.|YouTube |[Watch Video Tutorial](https://www.youtube.com/watch?v=O3OsH_Hpt1w) |
|3.|YouTube |[Subscribe to ProgrammingWizards TV Channel](https://www.youtube.com/c/programmingwizards) |
|4.|Camposha|[View All ListView Tutorials](https://camposha.info/android/listview)|

# Demo

Here is the demo:

![](/demo/demo1.png)

![](/demo/demo2.png)

![](/demo/demo3.png)
